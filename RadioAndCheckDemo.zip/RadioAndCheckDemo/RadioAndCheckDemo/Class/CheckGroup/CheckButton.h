//
//  CheckButton.h
//  SZLDEMO
//
//  Created by shizhili on 16/8/3.
//  Copyright © 2016年 upbest. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CheckHeader.h"

@class CheckButton;

@protocol SelectCheckDelegate <NSObject>
//以数组形式返回选中的按钮编号
-(void)selectCheckButtonIndex:(NSMutableArray*)indexArr;

@end
@interface CheckButton : UIView

@property(nonatomic,strong)NSString * title;//选项的标题
@property(nonatomic,strong)NSString * selectImageName;//选中状态的图片
@property(nonatomic,strong)NSString * unSelectImageName;//未选中状态的图片
@property(nonatomic,strong)NSArray<NSString *> * labelStringArr;//每一个按钮对应的内容
@property(nonatomic,strong)NSMutableArray      * selectIndexArr;//用来记录选中的index值
@property(nonatomic,weak)id<SelectCheckDelegate>delegate;

/**
 *  创建多选按钮群，只使用多选的，可以不导入单选类库框架
 *  没有默认创建按钮的位置，可以灵活调整按钮的竖直方向的位置
 *
 *  @param title             标题，也可以理解为试题的内容，默认居中显示
 *  @param selectImageName   选中选项后的图片，可以不填，默认使用类库自带图片
 *  @param unselectImageName 未选中选项时的图片，可以不填，默认使用类库自带图片
 *  @param labelStringArr    选项的内容项，可以不填，也可以填写多项，不一定只能是四个选项
 *
 *  @return 返回创建的CheckButton按钮，需要先创建CheckButton和他的位置。
 */
-(CheckButton*)initCheckButtonTitle:(NSString *)title selectImgName:(NSString *)selectImageName unselectImgName:(NSString *)unselectImageName labelArr:(NSArray *)labelStringArr;


@end
