//
//  CheckHeader.h
//  SZLDEMO
//
//  Created by shizhili on 16/8/3.
//  Copyright © 2016年 upbest. All rights reserved.
//

#ifndef CheckHeader_h
#define CheckHeader_h

#define SCREEN_WIDTH    [UIScreen mainScreen].bounds.size.width
#define SCREEN_HEIGHT   [UIScreen mainScreen].bounds.size.height
#define CONTENT_MARGIN  10.0f

#define RGBCOLOR(R,G,B) [UIColor colorWithRed:R/255.0 green:G/255.0 blue:B/255.0 alpha:1]
#define  Font(F)   [UIFont systemFontOfSize:F weight:1]

#define titleFont 20   //标题字体大小
#define labelFont 16   //选项字体大小

#import "UILabel+sizeHight.h"
#import "UIView+convenience.h"
#import "VertLabel.h"

#import "CheckButton.h"



#endif /* CheckHeader_h */
