//
//  RadioButton.h
//  SZLDEMO
//
//  Created by shizhili on 16/8/2.
//  Copyright © 2016年 upbest. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "RadioHeader.h"

@class RadioButton;

@protocol SelectRadioDelegate <NSObject>
//返回选中的按钮编号
#pragma 注意：如果返回的index为59999，表示没有选中行
-(void)selectRadioButtonIndex:(NSInteger)index;

@end


@interface RadioButton : UIView

@property(nonatomic,strong)NSString * title;//选项的标题
@property(nonatomic,strong)NSString * selectImageName;//选中状态的图片
@property(nonatomic,strong)NSString * unSelectImageName;//未选中状态的图片
@property(nonatomic,strong)NSArray<NSString *> * labelStringArr;//每一个按钮对应的内容
@property(nonatomic,weak)id<SelectRadioDelegate>delegate;

/**
 *  创建单选按钮群，只使用单选的，可以不导入多选类库框架
 *  没有默认创建按钮的位置，可以灵活调整按钮的竖直方向的位置
 *
 *  @param title             标题，也可以理解为试题的内容，默认居中显示
 *  @param selectImageName   选中选项后的图片，可以不填，默认使用类库自带图片
 *  @param unselectImageName 未选中选项时的图片，可以不填，默认使用类库自带图片
 *  @param labelStringArr    选项的内容项，可以不填，也可以填写多项，不一定只能是四个选项
 *
 *  @return 返回创建的RadioButton按钮，需要先创建RadioButton和他的位置。
 */
-(RadioButton*)initRadioButtonTitle:(NSString *)title selectImgName:(NSString *)selectImageName unselectImgName:(NSString *)unselectImageName labelArr:(NSArray *)labelStringArr;


@end
