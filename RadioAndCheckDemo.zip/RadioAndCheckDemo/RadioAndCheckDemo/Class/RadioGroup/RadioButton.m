//
//  RadioButton.m
//  SZLDEMO
//
//  Created by shizhili on 16/8/2.
//  Copyright © 2016年 upbest. All rights reserved.
//

#import "RadioButton.h"
#import "RadioButtonCell.h"

@interface RadioButton (){
    UILabel * _labelTitle;
    BOOL haveTap;//用来标识是否有已经被选中的选项
    NSInteger indexOld;//用来记录上一次选择的按钮，如果为59999的话，表示没有选中行
}

@end

@implementation RadioButton

-(RadioButton *)initRadioButtonTitle:(NSString *)title selectImgName:(NSString *)selectImageName unselectImgName:(NSString *)unselectImageName labelArr:(NSArray *)labelStringArr{
    
    if (self = [super init]) {
        self.title = title;
        self.selectImageName   = selectImageName;
        self.unSelectImageName = unselectImageName;
        self.labelStringArr    = labelStringArr;
        
        [self makeTitleView];
        
        [self makeRadioCell];
        
    }
    return self;
}
//标题的起始位置
-(void)makeTitleView{
    _labelTitle = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, 20)];
    _labelTitle.numberOfLines =0;
    _labelTitle.textAlignment = NSTextAlignmentCenter;
    _labelTitle.font = Font(titleFont);
    [_labelTitle sizeToFit];
    _labelTitle.text = self.title;
    CGFloat hi = [UILabel getHeightWithTitle:self.title font:titleFont];
    _labelTitle.frame =CGRectMake(0, 64, SCREEN_WIDTH, CONTENT_MARGIN*2+hi);
    [self addSubview:_labelTitle];
}
//创建cell视图
-(void)makeRadioCell{
    
    __block CGFloat cellInitHigh = _labelTitle.frameBottom;//设置cell高度的起始位置
    for(int i=0;i<self.labelStringArr.count;i++){
        
        __block RadioButtonCell * cell =  [[RadioButtonCell alloc] initWithFrame:CGRectMake(0, cellInitHigh, SCREEN_WIDTH, 35)];
        cell = [cell initRadioCell:self.labelStringArr[i] selectImg:self.selectImageName unselectImg:self.unSelectImageName cellSizeBlock:^(CGSize size) {
            cellInitHigh += size.height;
            cell.frameHeight = size.height;
        }];
        cell.tag = 60000+i;
        [self addSubview:cell];
        
        UITapGestureRecognizer * tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tapCellAction:)];
        tap.numberOfTapsRequired = 1;
        [cell addGestureRecognizer:tap];
    }
}
//点击cell以后
-(void)tapCellAction:(UIGestureRecognizer *)tap{
    NSInteger tag = tap.view.tag;

    if(haveTap){//存在已经被选中的选项
         RadioButtonCell * cell = [self viewWithTag:tag];
        //判断选择的这一个本来是不是选中状态
        if(tag==indexOld){//是原来选中的行
            [cell tapRadioCell];//取消选中
            haveTap = NO;
            indexOld = 59999;
            [self.delegate selectRadioButtonIndex:indexOld];

        }else{//不是原来选中的行
            RadioButtonCell *cellOld = [self viewWithTag:indexOld];
            [cellOld tapRadioCell];//取消原来选中的行
            
            [cell tapRadioCell];//选中新行
            [self.delegate selectRadioButtonIndex:tag-60000];
            haveTap = YES;
            indexOld = tag;
        }
    }else{//不存在已经被选中的选项
        RadioButtonCell * cell = [self viewWithTag:tag];
        [cell tapRadioCell];
        if (cell.tapState) {//选中某一行状态，返回选中的行
            [self.delegate selectRadioButtonIndex:tag-60000];
        }
        indexOld =tag;//记录下选择的按钮行
        haveTap = YES;

    }
    
}


#pragma 初始化这些配置参数

-(NSString *)title{
    if (!_title) {
        _title = _title==nil?@"请输入标题":_title;
    }
    return _title;
}

-(NSString *)selectImageName{
    if (!_selectImageName) {
        _selectImageName =_selectImageName==nil?@"RadioButton-Selected.png":_selectImageName;
    }
    return _selectImageName;
}
-(NSString *)unSelectImageName{
    if (!_unSelectImageName) {
        _unSelectImageName = _unSelectImageName==nil?@"RadioButton-Unselected.png":_unSelectImageName;
    }
    return _unSelectImageName;
}
-(NSArray<NSString *> *)labelStringArr{
    if (!_labelStringArr) {
        _labelStringArr =_labelStringArr==nil?@[@"AAAA",@"BBBB",@"CCCC",@"DDDD"]:_labelStringArr;
    }
    return _labelStringArr;
    
}

@end
