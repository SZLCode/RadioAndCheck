//
//  RadioButtonCell.m
//  SZLDEMO
//
//  Created by shizhili on 16/8/2.
//  Copyright © 2016年 upbest. All rights reserved.
//

#import "RadioButtonCell.h"

@interface RadioButtonCell (){
    UIView      * _tapView;
    UIImageView    * _btnView;
    VertLabel     * _labelView;
}

@end

@implementation RadioButtonCell


-(instancetype)initRadioCell:(NSString *)cellTitle selectImg:(NSString *)seletImg unselectImg:(NSString*)unselectImg cellSizeBlock:(void (^)(CGSize))callBackSize{

    if (self=[super init]) {
        self.selectImageName = seletImg;
        self.unSelectImageName = unselectImg;
        self.celltitle = cellTitle;
        
        [self makecellView];
        
        CGSize size = CGSizeMake(SCREEN_WIDTH, _labelView.frameHeight);
        _tapView.frameHeight = size.height;
        callBackSize(size);
    }
    return self;
}
//cell的内容
-(void)makecellView{
    _tapView = [UIView new];
    _tapView.frame = CGRectMake(CONTENT_MARGIN, 0, SCREEN_WIDTH-CONTENT_MARGIN*2, 35);
    [self addSubview:_tapView];
    
    _btnView = [UIImageView new];
    _btnView.frame = CGRectMake(0, 3, 24, 24);
    _btnView.image = [UIImage imageNamed:self.unSelectImageName];
    [_tapView addSubview:_btnView];
    
    CGFloat cellHight =[UILabel getHeightWithTitle:self.celltitle font:16];
    _labelView = [VertLabel new];
    _labelView.text = self.celltitle;
    _labelView.font = Font(labelFont);
    _labelView.numberOfLines = 0;
    [_labelView sizeToFit];
    _labelView.frame = CGRectMake(_btnView.frameRight+CONTENT_MARGIN, 0, _tapView.frameRight-(_btnView.frameRight+CONTENT_MARGIN), cellHight+CONTENT_MARGIN*2);
    [_tapView addSubview:_labelView];

}
//单击按钮行,根据选中状态判断选中还是不选中
-(void)tapRadioCell{
    if (self.tapState) {
        [self cancelSelectedRadioCell];
    }else{
        [self selectRadioCell];
    }
    self.tapState = !self.tapState;
}
//标识为选中状态
#pragma 可以在这里修改选中以后label不标红，默认是标红的
-(void)selectRadioCell{
    _btnView.image = [UIImage imageNamed:self.selectImageName];
    _labelView.textColor = [UIColor redColor];
}
//取消选中状态
-(void)cancelSelectedRadioCell{
    _btnView.image = [UIImage imageNamed:self.unSelectImageName];
    _labelView.textColor = [UIColor blackColor];
}

#pragma 初始化这些配置参数
-(NSString *)selectImageName{
    if (!_selectImageName) {
        _selectImageName =_selectImageName==nil?@"RadioButton-Selected.png":_selectImageName;
    }
    return _selectImageName;
}
-(NSString *)unSelectImageName{
    if (!_unSelectImageName) {
        _unSelectImageName = _unSelectImageName==nil?@"RadioButton-Unselected.png":_unSelectImageName;
    }
    return _unSelectImageName;
}
-(NSString *)celltitle{
    if (!_celltitle) {
        _celltitle = @"我是cell内容";
    }
    return _celltitle;
}
-(NSString *)cellIndex{
    if (!_cellIndex) {
        _cellIndex = @"cellIndex";
    }
    return _cellIndex;
}
@end
