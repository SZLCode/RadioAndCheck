//
//  RadioButtonCell.h
//  SZLDEMO
//
//  Created by shizhili on 16/8/2.
//  Copyright © 2016年 upbest. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "RadioHeader.h"

@interface RadioButtonCell : UIView

@property(nonatomic,strong)NSString * cellIndex;//用来标识每一个cell
@property(nonatomic,strong)NSString * celltitle;//每一行cell的标题
@property(nonatomic,strong)NSString * selectImageName;//选中状态的图片
@property(nonatomic,strong)NSString * unSelectImageName;//未选中状态的图片
@property(assign)BOOL tapState;//按钮的选中状态

/**
 *  初始化按钮的行
 *
 *  @param cellTitle    cell内容列
 *  @param seletImg     选中时的图片
 *  @param unselectImg  未选中时的图片
 *  @param callBackSize 返回这一列cell的高度
 *
 *  @return 多选按钮的cell行
 */
-(instancetype)initRadioCell:(NSString *)cellTitle selectImg:(NSString *)seletImg unselectImg:(NSString*)unselectImg cellSizeBlock:(void(^)(CGSize size))callBackSize;

//单击按钮行，用来取消或者选中行
-(void)tapRadioCell;


@end
