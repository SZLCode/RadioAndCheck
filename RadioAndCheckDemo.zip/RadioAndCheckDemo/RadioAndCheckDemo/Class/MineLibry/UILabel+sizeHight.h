//
//  UILabel+sizeHight.h
//  SZLYGJLB
//
//  Created by shizhili on 16/8/2.
//  Copyright © 2016年 upbest. All rights reserved.
//

#import <UIKit/UIKit.h>
#define SCREEN_WIDTH    [UIScreen mainScreen].bounds.size.width
#define SCREEN_HEIGHT   [UIScreen mainScreen].bounds.size.height

@interface UILabel (sizeHight)
/**
获得label的高度
 */
+ (CGFloat)getHeightWithTitle:(NSString *)title font:(CGFloat)font;

/**
 获得label的宽度
 */
+ (CGFloat)getWidthWithTitle:(NSString *)title font:(CGFloat)font;

@end
