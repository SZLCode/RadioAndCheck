//
//  VertLabel.h
//  szlPVUnion
//
//  Created by shizhili on 16/7/22.
//  Copyright © 2016年 upbest. All rights reserved.
//

#import <UIKit/UIKit.h>

/**
 设置label不在竖直方向上居中显示，默认是居顶部开始显示
 */
typedef enum
{
    VerticalAlignmentTop = 0, // default
    VerticalAlignmentMiddle,
    VerticalAlignmentBottom,
} VerticalAlignment;

@interface VertLabel : UILabel

@property (nonatomic) VerticalAlignment verticalAlignment;

@end
