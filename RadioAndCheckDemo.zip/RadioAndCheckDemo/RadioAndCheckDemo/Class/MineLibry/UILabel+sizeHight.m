//
//  UILabel+sizeHight.m
//  SZLYGJLB
//
//  Created by shizhili on 16/8/2.
//  Copyright © 2016年 upbest. All rights reserved.
//

#import "UILabel+sizeHight.h"

@implementation UILabel (sizeHight)

+ (CGFloat)getWidthWithTitle:(NSString *)title font:(CGFloat)font {
    UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 1000, 0)];
    label.text = title;
    label.font = [UIFont systemFontOfSize:font];
    [label sizeToFit];
    return label.frame.size.width;
}

+ (CGFloat)getHeightWithTitle:(NSString *)title font:(CGFloat)font {
    UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, 1000)];
    label.text = title;
    label.numberOfLines = 0;
    label.font = [UIFont systemFontOfSize:font];
    [label sizeToFit];
    return label.frame.size.height;
}

@end
