//
//  RadioViewCtl.h
//  RadioAndCheckDemo
//
//  Created by shizhili on 16/8/3.
//  Copyright © 2016年 shizhili. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "RadioHeader.h"

@interface RadioViewCtl : UIViewController<SelectRadioDelegate>

@end
