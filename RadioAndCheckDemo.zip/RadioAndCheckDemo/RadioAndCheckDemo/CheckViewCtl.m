//
//  CheckViewCtl.m
//  RadioAndCheckDemo
//
//  Created by shizhili on 16/8/3.
//  Copyright © 2016年 shizhili. All rights reserved.
//

#import "CheckViewCtl.h"

@implementation CheckViewCtl

-(void)awakeFromNib{
    
    CheckButton *checkBtn = [[CheckButton alloc]initWithFrame:CGRectMake(0, 20, 414, 736)];
    checkBtn.delegate = self;
    checkBtn = [checkBtn initCheckButtonTitle:nil selectImgName:nil unselectImgName:nil labelArr:@[@"AAAAAAAAAAAAAAAAAAA",@"BBBBBBBBBBBBB",@"这个是多选项哦，这个是多选项哦，多选项哦，选项哦，项哦，哦！",@"DDDDDDDDDDDDDDD",@"EEEEEEEEEEEEEE",@"这个是最后一项，我可以继续增加很多选项哦，不信你可以增加GGGGGGGGGGGG来试一下哦！"]];
    
    [self.view addSubview:checkBtn];
}
#pragma checkDelegate
-(void)selectCheckButtonIndex:(NSMutableArray *)indexArr{
    if (indexArr.count) {
        NSArray * arr = @[@"AAA",@"BBB",@"CCC",@"DDD",@"EEE",@"FFF",@"GGG",@"HHH",@"III"];
        for (int i=0; i<indexArr.count; i++) {
            NSInteger index = [indexArr[i] integerValue];
            NSLog(@"我是%@选项",arr[index]);
        }
    }else{
        NSLog(@"没有选项！");
    }
 


}
@end
