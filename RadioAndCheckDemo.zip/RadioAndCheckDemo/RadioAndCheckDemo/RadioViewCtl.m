//
//  RadioViewCtl.m
//  RadioAndCheckDemo
//
//  Created by shizhili on 16/8/3.
//  Copyright © 2016年 shizhili. All rights reserved.
//

#import "RadioViewCtl.h"

@implementation RadioViewCtl

-(void)awakeFromNib{
        RadioButton *radioButton = [[RadioButton alloc]initWithFrame:CGRectMake(0, 60, 414, 736)];
        radioButton.delegate = self;
        radioButton = [radioButton initRadioButtonTitle:@"请评价好坏" selectImgName:nil unselectImgName:nil labelArr:@[@"好",@"BBBBBBBBBBBBBBBBBBBBB",@"这是第三个选项，这是第三个选项，你看我可以自动换行哟！不信吗？看我换行给你看！"]];
    
        [self.view addSubview:radioButton];
}
#pragma radioDelegate
-(void)selectRadioButtonIndex:(NSInteger)index{
    if (index==59999) {
        NSLog(@"没有选项");
    }else{
        NSArray * arr = @[@"AAA",@"BBB",@"CCC",@"DDD",@"EEE",@"FFF",@"GGG",@"HHH",@"III"];
        NSLog(@"我是%@",arr[index]);
    }
  
}
@end
