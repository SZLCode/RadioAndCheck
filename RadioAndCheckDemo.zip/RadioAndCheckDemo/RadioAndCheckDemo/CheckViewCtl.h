//
//  CheckViewCtl.h
//  RadioAndCheckDemo
//
//  Created by shizhili on 16/8/3.
//  Copyright © 2016年 shizhili. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CheckHeader.h"

@interface CheckViewCtl : UIViewController<SelectCheckDelegate>

@end
